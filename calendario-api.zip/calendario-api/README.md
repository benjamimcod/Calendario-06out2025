# calendario-gabriel-api
relembrança do node
# Necessidades
-deletar os json. menos o feriados.json
-rodar no terminal:
  -npm init
  -npm install express
  -npm install fs
  # Dependencias Novas
  -cors